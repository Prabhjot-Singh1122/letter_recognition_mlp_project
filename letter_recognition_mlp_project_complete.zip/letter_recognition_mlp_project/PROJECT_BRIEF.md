# Letter recognition project brief

## Aim

Develop and evaluate a multiclass classifier that predicts capital letters from the 16 numerical features in the UCI Letter Recognition dataset.

## Required work

1. Explain the dataset, target and feature representation.
2. Preserve separate training, validation and test data.
3. Train and evaluate the supplied MLP classifier.
4. Report accuracy, macro F1, log loss and a confusion matrix.
5. Compare training and held-out performance when discussing overfitting.
6. Demonstrate the Flask interface using unseen test examples.
7. Discuss the limitations of extracted features and model confidence.
8. Make one justified experimental change and compare its validation performance with the supplied configuration.

## Scope

This is an introductory project. A well-explained MLP and one controlled comparison are sufficient. Transfer learning and raw-image processing are outside the required scope.

## Assessment emphasis

The quality of the method and explanation matters more than achieving the highest possible accuracy. Marks should recognise correct splitting, prevention of leakage, reproducibility, appropriate metrics, evidence-based interpretation and honest limitations.

