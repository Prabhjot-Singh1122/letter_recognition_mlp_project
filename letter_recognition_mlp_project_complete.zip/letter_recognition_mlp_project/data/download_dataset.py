"""Download and verify the official UCI Letter Recognition dataset."""

import hashlib
import tempfile
import urllib.request
import zipfile
from pathlib import Path


URL = "https://archive.ics.uci.edu/static/public/59/letter%2Brecognition.zip"
EXPECTED_DATA_SHA256 = "2b89f3602cf768d3c8355267d2f13f2417809e101fc2b5ceee10db19a60de6e2"
DATA_DIR = Path(__file__).resolve().parent


def main():
    with tempfile.TemporaryDirectory(prefix="letter_data_") as temporary:
        archive = Path(temporary) / "letter_recognition.zip"
        print("Downloading the official UCI archive...")
        urllib.request.urlretrieve(URL, archive)
        with zipfile.ZipFile(archive) as zipped:
            data_bytes = zipped.read("letter-recognition.data")
            digest = hashlib.sha256(data_bytes).hexdigest()
            if digest != EXPECTED_DATA_SHA256:
                raise RuntimeError(
                    "The downloaded data checksum differs from the verified project copy. "
                    "Check the UCI dataset page before continuing."
                )
            (DATA_DIR / "letter-recognition.data").write_bytes(data_bytes)
            (DATA_DIR / "letter-recognition.names").write_bytes(
                zipped.read("letter-recognition.names")
            )
    print(f"Dataset ready in {DATA_DIR}")


if __name__ == "__main__":
    main()
