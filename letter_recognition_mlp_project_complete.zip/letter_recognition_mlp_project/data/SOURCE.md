# Dataset source

This project uses the **Letter Recognition** dataset from the UCI Machine Learning Repository.

- Creator: David Slate
- Donated: 1991
- UCI dataset identifier: 59
- Records: 20,000
- Inputs: 16 integer features
- Target: one capital letter from A to Z
- Missing values: none
- Dataset page: https://archive.ics.uci.edu/dataset/59/letter+recognition
- DOI: https://doi.org/10.24432/C5ZP40
- Licence: Creative Commons Attribution 4.0 International

Suggested citation:

> Slate, D. (1991). Letter Recognition [Dataset]. UCI Machine Learning Repository. https://doi.org/10.24432/C5ZP40

The included `letter-recognition.data` file has SHA-256 checksum:

`2b89f3602cf768d3c8355267d2f13f2417809e101fc2b5ceee10db19a60de6e2`

The repository recommends training on the first 16,000 records and testing on the final 4,000. This project preserves those final 4,000 records as the test set and divides the first 16,000 into 14,000 training and 2,000 validation records.

