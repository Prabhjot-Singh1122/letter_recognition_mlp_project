from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parent
DATA_DIR = PROJECT_ROOT / "data"
DATA_FILE = DATA_DIR / "letter-recognition.data"
SPLIT_DIR = DATA_DIR / "splits"
MODEL_DIR = PROJECT_ROOT / "model_resources"
MODEL_FILE = MODEL_DIR / "model_bundle.joblib"
EVALUATION_FILE = MODEL_DIR / "evaluation.json"
HISTORY_FILE = MODEL_DIR / "training_history.csv"

RANDOM_STATE = 42
DEVELOPMENT_ROWS = 16_000
VALIDATION_ROWS = 2_000

FEATURES = [
    ("x_box", "Horizontal position of the character box"),
    ("y_box", "Vertical position of the character box"),
    ("width", "Width of the character box"),
    ("height", "Height of the character box"),
    ("on_pixels", "Number of foreground pixels"),
    ("x_mean", "Mean horizontal position of foreground pixels"),
    ("y_mean", "Mean vertical position of foreground pixels"),
    ("x_variance", "Horizontal position variance"),
    ("y_variance", "Vertical position variance"),
    ("xy_correlation", "Correlation between horizontal and vertical position"),
    ("x2y_mean", "Mean of the horizontal squared by vertical position"),
    ("xy2_mean", "Mean of the horizontal by vertical squared position"),
    ("x_edge_mean", "Mean horizontal edge count"),
    ("x_edge_correlation", "Correlation of horizontal edge count with vertical position"),
    ("y_edge_mean", "Mean vertical edge count"),
    ("y_edge_correlation", "Correlation of vertical edge count with horizontal position"),
]

FEATURE_NAMES = [name for name, _ in FEATURES]
FEATURE_DESCRIPTIONS = {name: description for name, description in FEATURES}
TARGET_NAME = "letter"

