const featureGrid = document.querySelector("#feature-grid");
const form = document.querySelector("#prediction-form");
const errorBox = document.querySelector("#form-error");
const resultPanel = document.querySelector("#result-panel");
const sampleLabel = document.querySelector("#sample-label");
let featureNames = [];
let descriptions = {};
let activeSampleId = null;
let originalSampleValues = null;

function percent(value) {
  return `${(value * 100).toFixed(1)}%`;
}

function setMetric(id, value) {
  document.querySelector(id).textContent = percent(value);
}

function makeFeatureFields() {
  featureGrid.replaceChildren();
  featureNames.forEach((name) => {
    const wrapper = document.createElement("div");
    wrapper.className = "feature-field";
    const label = document.createElement("label");
    label.htmlFor = `feature-${name}`;
    label.textContent = name.replaceAll("_", " ");
    const input = document.createElement("input");
    input.id = `feature-${name}`;
    input.name = name;
    input.type = "number";
    input.min = "0";
    input.max = "15";
    input.step = "1";
    input.value = "0";
    input.required = true;
    input.addEventListener("input", updateSampleState);
    const help = document.createElement("small");
    help.textContent = descriptions[name];
    wrapper.append(label, input, help);
    featureGrid.append(wrapper);
  });
}

function currentValues() {
  return featureNames.map((name) => Number(document.querySelector(`#feature-${name}`).value));
}

function updateSampleState() {
  if (!originalSampleValues) return;
  const unchanged = currentValues().every((value, index) => value === originalSampleValues[index]);
  if (!unchanged) {
    activeSampleId = null;
    sampleLabel.textContent = "Values changed: true label will remain hidden";
  }
}

async function loadMetadata() {
  try {
    const response = await fetch("/api/metadata");
    if (!response.ok) throw new Error("Model metadata could not be loaded.");
    const data = await response.json();
    featureNames = data.feature_names;
    descriptions = data.feature_descriptions;
    makeFeatureFields();
    setMetric("#training-accuracy", data.metrics.training.accuracy);
    setMetric("#validation-accuracy", data.metrics.validation.accuracy);
    setMetric("#test-accuracy", data.metrics.test.accuracy);
    setMetric("#test-f1", data.metrics.test.macro_f1);
    document.querySelector("#split-summary").textContent =
      `${data.split_sizes.training.toLocaleString()} training, ${data.split_sizes.validation.toLocaleString()} validation and ${data.split_sizes.test.toLocaleString()} untouched test records. Best model saved at epoch ${data.training_process.best_epoch}.`;
    const status = document.querySelector("#model-status");
    status.textContent = "Model ready";
  } catch (error) {
    document.querySelector("#model-status").textContent = "Model unavailable";
    errorBox.textContent = `${error.message} Run training.py and refresh this page.`;
  }
}

document.querySelector("#load-sample").addEventListener("click", async () => {
  errorBox.textContent = "";
  try {
    const response = await fetch("/api/random-sample");
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "Could not load a sample.");
    featureNames.forEach((name) => {
      document.querySelector(`#feature-${name}`).value = data.features[name];
    });
    activeSampleId = data.sample_id;
    originalSampleValues = currentValues();
    sampleLabel.textContent = `Loaded untouched test record ${data.sample_id}`;
    resultPanel.hidden = true;
  } catch (error) {
    errorBox.textContent = error.message;
  }
});

document.querySelector("#reset-values").addEventListener("click", () => {
  featureNames.forEach((name) => document.querySelector(`#feature-${name}`).value = 0);
  activeSampleId = null;
  originalSampleValues = null;
  sampleLabel.textContent = "Manual input";
  errorBox.textContent = "";
  resultPanel.hidden = true;
});

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  errorBox.textContent = "";
  const values = currentValues();
  if (values.some((value) => !Number.isFinite(value) || value < 0 || value > 15)) {
    errorBox.textContent = "Enter 16 numerical values between 0 and 15.";
    return;
  }
  try {
    const response = await fetch("/api/predict", {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify({features: values, sample_id: activeSampleId}),
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "Prediction failed.");
    showResult(data);
  } catch (error) {
    errorBox.textContent = error.message;
  }
});

function showResult(data) {
  document.querySelector("#predicted-letter").textContent = data.predicted_letter;
  document.querySelector("#prediction-text").textContent =
    `Predicted ${data.predicted_letter} with ${percent(data.confidence)} confidence`;
  const actual = document.querySelector("#actual-result");
  if (data.actual_letter) {
    actual.textContent = data.correct
      ? `Correct. The recorded letter is ${data.actual_letter}.`
      : `Incorrect. The recorded letter is ${data.actual_letter}.`;
    actual.style.color = data.correct ? "var(--success)" : "var(--danger)";
  } else {
    actual.textContent = "No true label is available for this manual or modified input.";
    actual.style.color = "var(--muted)";
  }
  const list = document.querySelector("#probability-list");
  list.replaceChildren();
  data.top_predictions.forEach((item) => {
    const row = document.createElement("div");
    row.className = "probability-row";
    const letter = document.createElement("strong");
    letter.textContent = item.letter;
    const bar = document.createElement("div");
    bar.className = "bar";
    const fill = document.createElement("span");
    fill.style.width = percent(item.confidence);
    bar.append(fill);
    const score = document.createElement("output");
    score.textContent = percent(item.confidence);
    row.append(letter, bar, score);
    list.append(row);
  });
  resultPanel.hidden = false;
  resultPanel.scrollIntoView({behavior: "smooth", block: "center"});
}

loadMetadata();

