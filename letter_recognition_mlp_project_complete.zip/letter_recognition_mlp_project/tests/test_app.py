import unittest

from app import create_app


class FlaskApplicationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.client = create_app(testing=True).test_client()

    def test_homepage_loads(self):
        response = self.client.get("/")
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"Letter Recognition Lab", response.data)

    def test_health_endpoint(self):
        response = self.client.get("/health")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.get_json()["status"], "ok")

    def test_random_sample_can_be_predicted_and_checked(self):
        sample = self.client.get("/api/random-sample").get_json()
        response = self.client.post(
            "/api/predict",
            json={"features": sample["features"], "sample_id": sample["sample_id"]},
        )
        self.assertEqual(response.status_code, 200)
        result = response.get_json()
        self.assertIn("actual_letter", result)
        self.assertIn("correct", result)

    def test_invalid_json_is_rejected(self):
        response = self.client.post(
            "/api/predict", data="not json", content_type="text/plain"
        )
        self.assertEqual(response.status_code, 400)

    def test_missing_and_out_of_range_features_are_rejected(self):
        self.assertEqual(self.client.post("/api/predict", json={}).status_code, 400)
        response = self.client.post("/api/predict", json={"features": [99] * 16})
        self.assertEqual(response.status_code, 400)


if __name__ == "__main__":
    unittest.main()

