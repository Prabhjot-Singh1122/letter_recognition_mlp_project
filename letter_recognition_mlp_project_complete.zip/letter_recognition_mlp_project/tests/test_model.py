import unittest

import numpy as np
from sklearn.metrics import accuracy_score

from model_service import (
    load_bundle,
    load_test_data,
    predict,
    random_test_sample,
    validate_features,
)
from project_config import FEATURE_NAMES, TARGET_NAME


class ModelServiceTests(unittest.TestCase):
    def test_model_returns_ranked_letter_predictions(self):
        sample = random_test_sample()
        result = predict(sample["features"])
        self.assertIn(result["predicted_letter"], "ABCDEFGHIJKLMNOPQRSTUVWXYZ")
        self.assertEqual(len(result["top_predictions"]), 5)
        scores = [item["confidence"] for item in result["top_predictions"]]
        self.assertEqual(scores, sorted(scores, reverse=True))
        self.assertTrue(0 <= result["confidence"] <= 1)

    def test_feature_dictionary_must_have_exact_names(self):
        with self.assertRaises(ValueError):
            validate_features({FEATURE_NAMES[0]: 1})

    def test_feature_values_must_be_in_range(self):
        with self.assertRaises(ValueError):
            validate_features([0] * 15 + [16])

    def test_saved_model_reproduces_reported_test_accuracy(self):
        bundle = load_bundle()
        test = load_test_data()
        scaled = bundle["scaler"].transform(
            test[FEATURE_NAMES].to_numpy(dtype=np.float64)
        )
        predicted = bundle["model"].predict(scaled)
        self.assertAlmostEqual(accuracy_score(test[TARGET_NAME], predicted), 0.93, places=6)


if __name__ == "__main__":
    unittest.main()
