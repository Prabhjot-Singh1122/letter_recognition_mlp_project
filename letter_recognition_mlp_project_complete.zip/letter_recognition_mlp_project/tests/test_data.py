import string
import unittest

from data_utils import load_dataset, make_splits
from project_config import FEATURE_NAMES, TARGET_NAME


class DatasetTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.frame = load_dataset()
        cls.splits = make_splits(cls.frame)

    def test_official_dataset_shape_and_range(self):
        self.assertEqual(self.frame.shape, (20_000, 18))
        self.assertEqual(set(self.frame[TARGET_NAME]), set(string.ascii_uppercase))
        values = self.frame[FEATURE_NAMES]
        self.assertTrue(((values >= 0) & (values <= 15)).all().all())

    def test_split_sizes(self):
        self.assertEqual(len(self.splits.training), 14_000)
        self.assertEqual(len(self.splits.validation), 2_000)
        self.assertEqual(len(self.splits.test), 4_000)

    def test_splits_do_not_overlap(self):
        train_ids = set(self.splits.training.row_id)
        validation_ids = set(self.splits.validation.row_id)
        test_ids = set(self.splits.test.row_id)
        self.assertFalse(train_ids & validation_ids)
        self.assertFalse(train_ids & test_ids)
        self.assertFalse(validation_ids & test_ids)
        self.assertEqual(min(test_ids), 16_001)

    def test_every_class_appears_in_every_split(self):
        expected = set(string.ascii_uppercase)
        for part in (self.splits.training, self.splits.validation, self.splits.test):
            self.assertEqual(set(part[TARGET_NAME]), expected)


if __name__ == "__main__":
    unittest.main()

