from __future__ import annotations

import argparse
import copy
import csv
import json
import time
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.metrics import (
    accuracy_score,
    classification_report,
    confusion_matrix,
    f1_score,
    log_loss,
)
from sklearn.neural_network import MLPClassifier
from sklearn.preprocessing import StandardScaler

from data_utils import load_dataset, make_splits, save_splits
from project_config import (
    EVALUATION_FILE,
    FEATURE_DESCRIPTIONS,
    FEATURE_NAMES,
    HISTORY_FILE,
    MODEL_DIR,
    MODEL_FILE,
    RANDOM_STATE,
    TARGET_NAME,
)


def metrics_for(model, x, y, labels):
    probabilities = model.predict_proba(x)
    predictions = model.classes_[np.argmax(probabilities, axis=1)]
    report = classification_report(
        y, predictions, labels=labels, output_dict=True, zero_division=0
    )
    return {
        "accuracy": float(accuracy_score(y, predictions)),
        "macro_f1": float(f1_score(y, predictions, average="macro")),
        "weighted_f1": float(f1_score(y, predictions, average="weighted")),
        "log_loss": float(log_loss(y, probabilities, labels=labels)),
        "per_class": {
            label: {
                key: float(report[label][key])
                for key in ("precision", "recall", "f1-score")
            }
            | {"support": int(report[label]["support"])}
            for label in labels
        },
        "confusion_matrix": confusion_matrix(y, predictions, labels=labels).tolist(),
    }


def train(max_epochs=200, patience=20, min_delta=1e-4):
    np.random.seed(RANDOM_STATE)
    frame = load_dataset()
    splits = make_splits(frame)
    save_splits(splits)

    x_train = splits.training[FEATURE_NAMES].to_numpy(dtype=np.float64)
    y_train = splits.training[TARGET_NAME].to_numpy()
    x_validation = splits.validation[FEATURE_NAMES].to_numpy(dtype=np.float64)
    y_validation = splits.validation[TARGET_NAME].to_numpy()
    x_test = splits.test[FEATURE_NAMES].to_numpy(dtype=np.float64)
    y_test = splits.test[TARGET_NAME].to_numpy()

    scaler = StandardScaler()
    x_train_scaled = scaler.fit_transform(x_train)
    x_validation_scaled = scaler.transform(x_validation)
    x_test_scaled = scaler.transform(x_test)

    labels = np.array(sorted(np.unique(y_train)))
    model = MLPClassifier(
        hidden_layer_sizes=(64, 32),
        activation="relu",
        solver="adam",
        alpha=0.0005,
        batch_size=128,
        learning_rate_init=0.001,
        shuffle=True,
        random_state=RANDOM_STATE,
    )

    best_model = None
    best_validation_loss = float("inf")
    best_epoch = 0
    epochs_without_improvement = 0
    history = []
    started = time.perf_counter()

    for epoch in range(1, max_epochs + 1):
        model.partial_fit(x_train_scaled, y_train, classes=labels)
        train_probabilities = model.predict_proba(x_train_scaled)
        validation_probabilities = model.predict_proba(x_validation_scaled)
        train_predictions = model.classes_[np.argmax(train_probabilities, axis=1)]
        validation_predictions = model.classes_[np.argmax(validation_probabilities, axis=1)]

        row = {
            "epoch": epoch,
            "training_loss": float(log_loss(y_train, train_probabilities, labels=labels)),
            "validation_loss": float(
                log_loss(y_validation, validation_probabilities, labels=labels)
            ),
            "training_accuracy": float(accuracy_score(y_train, train_predictions)),
            "validation_accuracy": float(
                accuracy_score(y_validation, validation_predictions)
            ),
            "validation_macro_f1": float(
                f1_score(y_validation, validation_predictions, average="macro")
            ),
        }
        history.append(row)

        if row["validation_loss"] < best_validation_loss - min_delta:
            best_validation_loss = row["validation_loss"]
            best_epoch = epoch
            best_model = copy.deepcopy(model)
            epochs_without_improvement = 0
        else:
            epochs_without_improvement += 1

        if epoch == 1 or epoch % 10 == 0:
            print(
                f"Epoch {epoch:3d} | train acc {row['training_accuracy']:.4f} "
                f"| validation acc {row['validation_accuracy']:.4f} "
                f"| validation loss {row['validation_loss']:.4f}"
            )
        if epoch >= 25 and epochs_without_improvement >= patience:
            print(f"Early stopping at epoch {epoch}; restoring epoch {best_epoch}.")
            break

    if best_model is None:
        raise RuntimeError("Training did not produce a model.")
    model = best_model

    results = {
        "dataset": {
            "name": "UCI Letter Recognition",
            "uci_id": 59,
            "total_rows": len(frame),
            "feature_count": len(FEATURE_NAMES),
            "class_count": len(labels),
            "feature_range": [0, 15],
            "test_protocol": "UCI recommended final 4,000 rows reserved for test",
        },
        "split_sizes": {
            "training": len(splits.training),
            "validation": len(splits.validation),
            "test": len(splits.test),
        },
        "model": {
            "classifier": "scikit-learn MLPClassifier",
            "hidden_layers": [64, 32],
            "activation": "ReLU",
            "output_classes": 26,
            "regularisation_alpha": 0.0005,
            "batch_size": 128,
            "learning_rate": 0.001,
            "random_state": RANDOM_STATE,
        },
        "training_process": {
            "epochs_completed": len(history),
            "best_epoch": best_epoch,
            "early_stopping_patience": patience,
            "best_validation_loss": best_validation_loss,
            "elapsed_seconds": float(time.perf_counter() - started),
        },
        "metrics": {
            "training": metrics_for(model, x_train_scaled, y_train, labels),
            "validation": metrics_for(
                model, x_validation_scaled, y_validation, labels
            ),
            "test": metrics_for(model, x_test_scaled, y_test, labels),
        },
    }

    MODEL_DIR.mkdir(parents=True, exist_ok=True)
    joblib.dump(
        {
            "model": model,
            "scaler": scaler,
            "classes": labels.tolist(),
            "feature_names": FEATURE_NAMES,
            "feature_descriptions": FEATURE_DESCRIPTIONS,
            "feature_min": 0,
            "feature_max": 15,
            "random_state": RANDOM_STATE,
            "best_epoch": best_epoch,
        },
        MODEL_FILE,
    )
    EVALUATION_FILE.write_text(json.dumps(results, indent=2), encoding="utf-8")
    pd.DataFrame(
        results["metrics"]["test"]["confusion_matrix"],
        index=labels,
        columns=labels,
    ).rename_axis("actual").to_csv(MODEL_DIR / "test_confusion_matrix.csv")

    test_probabilities = model.predict_proba(x_test_scaled)
    test_predictions = model.classes_[np.argmax(test_probabilities, axis=1)]
    prediction_rows = splits.test[["row_id", TARGET_NAME]].copy()
    prediction_rows["predicted_letter"] = test_predictions
    prediction_rows["confidence"] = np.max(test_probabilities, axis=1)
    prediction_rows["correct"] = prediction_rows[TARGET_NAME] == test_predictions
    prediction_rows.to_csv(MODEL_DIR / "test_predictions.csv", index=False)
    with HISTORY_FILE.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=history[0].keys())
        writer.writeheader()
        writer.writerows(history)

    summary = {
        "split_sizes": results["split_sizes"],
        "best_epoch": best_epoch,
        "metrics": {
            split_name: {
                "accuracy": values["accuracy"],
                "macro_f1": values["macro_f1"],
                "log_loss": values["log_loss"],
            }
            for split_name, values in results["metrics"].items()
        },
    }
    print(json.dumps(summary, indent=2))
    print(f"Saved model to {MODEL_FILE}")
    print(f"Saved evaluation to {EVALUATION_FILE}")
    return results


def main():
    parser = argparse.ArgumentParser(description="Train the letter recognition MLP.")
    parser.add_argument("--max-epochs", type=int, default=200)
    parser.add_argument("--patience", type=int, default=20)
    args = parser.parse_args()
    train(max_epochs=args.max_epochs, patience=args.patience)


if __name__ == "__main__":
    main()
