from __future__ import annotations

import string
from dataclasses import dataclass

import pandas as pd
from sklearn.model_selection import train_test_split

from project_config import (
    DATA_FILE,
    DEVELOPMENT_ROWS,
    FEATURE_NAMES,
    RANDOM_STATE,
    SPLIT_DIR,
    TARGET_NAME,
    VALIDATION_ROWS,
)


@dataclass(frozen=True)
class DatasetSplits:
    training: pd.DataFrame
    validation: pd.DataFrame
    test: pd.DataFrame


def load_dataset(path=DATA_FILE) -> pd.DataFrame:
    """Load and validate the official UCI Letter Recognition data file."""
    if not path.exists():
        raise FileNotFoundError(
            f"Dataset not found at {path}. Run: python data/download_dataset.py"
        )

    columns = [TARGET_NAME, *FEATURE_NAMES]
    frame = pd.read_csv(path, header=None, names=columns)
    frame.insert(0, "row_id", range(1, len(frame) + 1))

    if frame.shape != (20_000, 18):
        raise ValueError(f"Expected 20,000 rows and 18 columns, found {frame.shape}.")
    if frame.isna().any().any():
        raise ValueError("The dataset unexpectedly contains missing values.")
    if set(frame[TARGET_NAME]) != set(string.ascii_uppercase):
        raise ValueError("The target column must contain all 26 capital letters A to Z.")
    values = frame[FEATURE_NAMES]
    if not ((values >= 0) & (values <= 15)).all().all():
        raise ValueError("All feature values must be integers between 0 and 15.")
    return frame


def make_splits(frame: pd.DataFrame) -> DatasetSplits:
    """Use the UCI final 4,000 rows as test data and split development data."""
    development = frame.iloc[:DEVELOPMENT_ROWS].copy()
    test = frame.iloc[DEVELOPMENT_ROWS:].copy()
    training, validation = train_test_split(
        development,
        test_size=VALIDATION_ROWS,
        random_state=RANDOM_STATE,
        stratify=development[TARGET_NAME],
    )
    training = training.sort_values("row_id").reset_index(drop=True)
    validation = validation.sort_values("row_id").reset_index(drop=True)
    test = test.reset_index(drop=True)

    id_sets = [set(part["row_id"]) for part in (training, validation, test)]
    if id_sets[0] & id_sets[1] or id_sets[0] & id_sets[2] or id_sets[1] & id_sets[2]:
        raise ValueError("Dataset splits overlap.")
    if [len(training), len(validation), len(test)] != [14_000, 2_000, 4_000]:
        raise ValueError("Unexpected dataset split sizes.")
    return DatasetSplits(training=training, validation=validation, test=test)


def save_splits(splits: DatasetSplits) -> None:
    SPLIT_DIR.mkdir(parents=True, exist_ok=True)
    splits.training.to_csv(SPLIT_DIR / "training.csv", index=False)
    splits.validation.to_csv(SPLIT_DIR / "validation.csv", index=False)
    splits.test.to_csv(SPLIT_DIR / "test.csv", index=False)

