from __future__ import annotations

import json
from functools import lru_cache

import joblib
import numpy as np
import pandas as pd

from project_config import (
    EVALUATION_FILE,
    FEATURE_NAMES,
    MODEL_FILE,
    SPLIT_DIR,
    TARGET_NAME,
)


class ModelNotReadyError(RuntimeError):
    pass


@lru_cache(maxsize=1)
def load_bundle():
    if not MODEL_FILE.exists():
        raise ModelNotReadyError("Model files are missing. Run training.py first.")
    return joblib.load(MODEL_FILE)


@lru_cache(maxsize=1)
def load_test_data():
    path = SPLIT_DIR / "test.csv"
    if not path.exists():
        raise ModelNotReadyError("Test split is missing. Run training.py first.")
    return pd.read_csv(path)


def validate_features(raw_features):
    if isinstance(raw_features, dict):
        missing = [name for name in FEATURE_NAMES if name not in raw_features]
        extra = [name for name in raw_features if name not in FEATURE_NAMES]
        if missing or extra:
            raise ValueError(
                f"Features must contain exactly these names: {', '.join(FEATURE_NAMES)}"
            )
        raw_features = [raw_features[name] for name in FEATURE_NAMES]
    if not isinstance(raw_features, list) or len(raw_features) != len(FEATURE_NAMES):
        raise ValueError(f"Provide exactly {len(FEATURE_NAMES)} feature values.")
    try:
        values = np.asarray(raw_features, dtype=np.float64)
    except (TypeError, ValueError) as exc:
        raise ValueError("Every feature must be a number.") from exc
    if not np.isfinite(values).all():
        raise ValueError("Feature values must be finite numbers.")
    if np.any(values < 0) or np.any(values > 15):
        raise ValueError("Every feature must be between 0 and 15.")
    return values


def predict(raw_features):
    bundle = load_bundle()
    values = validate_features(raw_features)
    scaled = bundle["scaler"].transform(values.reshape(1, -1))
    probabilities = bundle["model"].predict_proba(scaled)[0]
    order = np.argsort(probabilities)[::-1]
    top_predictions = [
        {
            "letter": str(bundle["model"].classes_[index]),
            "confidence": float(probabilities[index]),
        }
        for index in order[:5]
    ]
    return {
        "predicted_letter": top_predictions[0]["letter"],
        "confidence": top_predictions[0]["confidence"],
        "top_predictions": top_predictions,
    }


def random_test_sample():
    row = load_test_data().sample(n=1).iloc[0]
    return {
        "sample_id": int(row["row_id"]),
        "features": {name: float(row[name]) for name in FEATURE_NAMES},
    }


def actual_for_unchanged_sample(sample_id, values):
    if sample_id is None:
        return None
    try:
        sample_id = int(sample_id)
    except (TypeError, ValueError):
        return None
    matches = load_test_data().loc[lambda frame: frame["row_id"] == sample_id]
    if len(matches) != 1:
        return None
    row = matches.iloc[0]
    expected = row[FEATURE_NAMES].to_numpy(dtype=np.float64)
    if not np.allclose(expected, values):
        return None
    return str(row[TARGET_NAME])


def metadata():
    bundle = load_bundle()
    evaluation = json.loads(EVALUATION_FILE.read_text(encoding="utf-8"))
    compact_metrics = {
        name: {
            "accuracy": values["accuracy"],
            "macro_f1": values["macro_f1"],
        }
        for name, values in evaluation["metrics"].items()
    }
    return {
        "dataset": evaluation["dataset"],
        "split_sizes": evaluation["split_sizes"],
        "model": evaluation["model"],
        "training_process": evaluation["training_process"],
        "metrics": compact_metrics,
        "feature_names": bundle["feature_names"],
        "feature_descriptions": bundle["feature_descriptions"],
    }

