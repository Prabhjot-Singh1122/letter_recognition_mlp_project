# Results interpretation guide

## Overall result

The saved MLP achieved:

- 97.32% training accuracy;
- 92.45% validation accuracy;
- 93.00% test accuracy;
- 0.9297 test macro F1.

The training-to-test accuracy gap is 4.32 percentage points. This indicates some overfitting, but the gap is not severe. Validation and test accuracy differ by only 0.55 points, so the two held-out results support a similar conclusion.

## Per-class evidence

The lowest test F1 scores were:

| Letter | Test F1 | Test examples |
|---|---:|---:|
| H | 0.8119 | 151 |
| R | 0.8869 | 161 |
| B | 0.8906 | 136 |
| O | 0.9030 | 139 |
| F | 0.9034 | 153 |

This table does not explain why the errors occurred. It identifies classes that deserve closer inspection.

## Confusion-matrix evidence

The most frequent single test confusion was 12 records whose actual letter was P but whose predicted letter was F. Other notable confusions included:

- 7 actual L records predicted as X;
- 7 actual H records predicted as R;
- 5 actual U records predicted as W;
- 5 actual N records predicted as H;
- 5 actual J records predicted as I.

These observations should be linked to the feature representation. Do not assume two letters look similar in ordinary handwriting unless the dataset examples or extracted measurements support that claim.

## Example discussion paragraph

> The MLP achieved 93.00% test accuracy and a macro F1 score of 0.9297 on 4,000 untouched records. Training accuracy was 97.32%, producing a 4.32 percentage-point training-to-test gap and therefore some evidence of overfitting. Validation accuracy was 92.45%, only 0.55 points below test accuracy, so the held-out evaluations were consistent. Class H had the lowest test F1 score at 0.8119, and seven H records were predicted as R. The confusion matrix therefore shows that aggregate accuracy hides meaningful differences between letters.

Use this paragraph as a structural example. Students should write their own interpretation and update every number after running their own experiment.

