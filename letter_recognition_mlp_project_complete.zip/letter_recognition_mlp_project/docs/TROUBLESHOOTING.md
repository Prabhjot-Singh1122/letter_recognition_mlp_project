# Troubleshooting

## Python is not recognised

Install a 64-bit version of Python 3.11 or newer from python.org. During installation, select the option to add Python to PATH. Close and reopen Command Prompt, then run `setup.bat` again.

## Setup fails while installing packages

Check the internet connection and run:

```bat
.venv\Scripts\python.exe -m pip install --upgrade pip
.venv\Scripts\python.exe -m pip install -r requirements.txt
```

## The model is missing

The distributed project includes the model. If it was deleted or the code was changed, run:

```bat
train_model.bat
```

## The browser does not open

Keep the Command Prompt window open and manually visit:

```text
http://127.0.0.1:5000
```

## Port 5000 is already in use

Close the other application using port 5000. You can also change the port number in `run_local.py` and use the matching browser address.

## A prediction has no true answer

The GUI reveals the recorded answer only when an unchanged test example is loaded. Manual inputs and modified examples have no trustworthy true label.

## The result changed after retraining

Confirm that `random_state` remains 42 and that package versions are compatible. Small numerical differences can still occur across operating systems or library versions. Report the results produced by your own run.
