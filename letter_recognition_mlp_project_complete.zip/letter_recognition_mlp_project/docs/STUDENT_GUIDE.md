# Student guide

## The project question

Can a neural network identify a capital letter from measurements describing the shape of a distorted character image?

This is a **multiclass classification** problem. Each record belongs to exactly one of 26 classes, A to Z.

## What the program does

The project follows this sequence:

1. Read and validate the UCI data.
2. Keep the final 4,000 UCI records aside as the test set.
3. Split the first 16,000 records into training and validation sets.
4. Fit a StandardScaler using only the training inputs.
5. Train an MLP neural network on the scaled training data.
6. Check validation loss after every epoch and keep the best model.
7. Evaluate the selected model on the untouched test set.
8. Save the model, results and test predictions.
9. Let the Flask interface load the saved model and make predictions.

## Why there are three datasets

**Training data** teaches the model. The optimiser changes the model weights to reduce mistakes on these examples.

**Validation data** supports development decisions. This project uses validation loss to decide which training epoch to save.

**Test data** provides the final estimate on unseen examples. It must not be used to choose the model, feature scaling, number of epochs or other settings.

If test data influences model development, it is no longer a fair test.

## The classifier

The primary and only classifier is a scikit-learn `MLPClassifier`. MLP means multilayer perceptron.

- Input layer: 16 standardised features
- First hidden layer: 64 neurons with ReLU activation
- Second hidden layer: 32 neurons with ReLU activation
- Output: 26 class probabilities
- Optimiser: Adam
- Loss: multiclass logarithmic loss
- Regularisation: L2 penalty controlled by `alpha`
- Early stopping: implemented in `training.py` using validation loss

The code trains one epoch at a time with `partial_fit`. When validation loss stops improving, it restores the model from the best epoch.

## Why features are standardised

The `StandardScaler` centres each training feature and rescales it using the training standard deviation. Neural networks usually train more reliably when inputs have comparable scales.

The scaler is fitted on training data only. The same fitted scaler then transforms validation, test and GUI inputs. Fitting it on all records would leak information from held-out data.

## Understanding the metrics

**Accuracy** is the proportion of records given the correct letter.

**Precision** asks: when the model predicts a particular letter, how often is it correct?

**Recall** asks: of all records that truly belong to a particular letter, how many did the model find?

**F1** combines precision and recall.

**Macro F1** calculates F1 separately for every letter and then averages the 26 values equally. It prevents common classes from dominating the reported result.

**Log loss** evaluates the predicted probability distribution. Confident wrong answers receive a larger penalty.

## Interpreting the saved results

The saved model achieved 97.32% training accuracy, 92.45% validation accuracy and 93.00% test accuracy. The 4.32-point training-to-test gap suggests some overfitting, but it is much smaller than the gap seen with the previous tiny chatbot dataset. Validation and test performance are close, which supports a consistent interpretation.

Do not describe the result as perfect. Review the per-class metrics and confusion matrix to discover which letters remain difficult.

## Using the GUI

1. Run `setup.bat` once.
2. Run `run_app.bat`.
3. Select **Load random test example**.
4. Select **Predict letter**.
5. Compare the predicted and recorded letters.
6. Inspect the five highest model scores.
7. Change one feature and predict again. The recorded answer disappears because the values no longer represent the original test record.

## Safe experiments

Change one setting at a time, retrain and record the validation result. Possible introductory experiments include:

- one hidden layer versus two hidden layers;
- 32, 64 or 128 neurons;
- different `alpha` values;
- a different learning rate;
- training without feature standardisation;
- a simple logistic-regression baseline.

Choose settings using validation results. Evaluate the test set only after the final configuration is fixed.

## What not to claim

- The application does not read raw images.
- The 16 measurements are not ordinary pixel values.
- A high softmax score does not guarantee a correct answer.
- Manually entered values may not describe any realistic character.
- This model has not been evaluated on handwriting, photographs or fonts outside the dataset-generation process.

