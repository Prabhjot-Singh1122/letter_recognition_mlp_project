# Dataset guide

## Source and task

The project uses the UCI Letter Recognition dataset created by David Slate. It contains 20,000 examples generated from 20 fonts. Letters were randomly distorted and converted into 16 numerical measurements. Each measurement was scaled to an integer from 0 to 15.

The target column is the correct capital letter. The remaining columns are input features.

## Feature glossary

| Project name | Original name | Plain-language description |
|---|---|---|
| `x_box` | x-box | Horizontal position of the character box |
| `y_box` | y-box | Vertical position of the character box |
| `width` | width | Width of the character box |
| `height` | high | Height of the character box |
| `on_pixels` | onpix | Number of foreground pixels |
| `x_mean` | x-bar | Mean horizontal position of foreground pixels |
| `y_mean` | y-bar | Mean vertical position of foreground pixels |
| `x_variance` | x2bar | Horizontal position variance |
| `y_variance` | y2bar | Vertical position variance |
| `xy_correlation` | xybar | Correlation between horizontal and vertical position |
| `x2y_mean` | x2ybr | Mean of horizontal squared by vertical position |
| `xy2_mean` | xy2br | Mean of horizontal by vertical squared position |
| `x_edge_mean` | x-ege | Mean horizontal edge count |
| `x_edge_correlation` | xegvy | Correlation of horizontal edge count with vertical position |
| `y_edge_mean` | y-ege | Mean vertical edge count |
| `y_edge_correlation` | yegvx | Correlation of vertical edge count with horizontal position |

The feature descriptions above simplify the original technical labels. Consult `data/letter-recognition.names` and the UCI page when writing the formal dataset description.

## Split protocol

The UCI documentation recommends using the first 16,000 records for training and the final 4,000 for testing. This project refines that protocol:

- Training: 14,000 records selected from the first 16,000
- Validation: 2,000 stratified records selected from the first 16,000
- Test: the original final 4,000 records

Stratification keeps all 26 letters represented in training and validation. The random seed is 42.

## Checks performed by the code

`data_utils.py` verifies that:

- exactly 20,000 records are present;
- all 26 capital-letter labels are present;
- all 16 inputs are available;
- there are no missing values;
- every input is between 0 and 15;
- split row identifiers do not overlap.

## Licence and citation

The dataset is distributed under CC BY 4.0. Credit the source whenever the dataset or a derived project is shared.

Slate, D. (1991). *Letter Recognition* [Dataset]. UCI Machine Learning Repository. https://doi.org/10.24432/C5ZP40

