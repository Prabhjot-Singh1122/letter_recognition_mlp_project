# Model card

## Intended use

This model is an educational example of multiclass classification for an Introduction to AI module. It predicts one capital letter from 16 UCI Letter Recognition features.

It is suitable for demonstrating data splitting, standardisation, neural-network training, validation-based early stopping, test evaluation and a prediction interface.

## Model details

- Classifier: scikit-learn multilayer perceptron
- Hidden layers: 64 and 32 neurons
- Activation: ReLU
- Optimiser: Adam
- L2 regularisation parameter: 0.0005
- Batch size: 128
- Initial learning rate: 0.001
- Random seed: 42
- Best epoch: 79
- Epochs completed before early stopping: 99

## Evaluation

| Dataset | Size | Accuracy | Macro F1 | Log loss |
|---|---:|---:|---:|---:|
| Training | 14,000 | 0.9732 | 0.9730 | 0.0918 |
| Validation | 2,000 | 0.9245 | 0.9238 | 0.2342 |
| Test | 4,000 | 0.9300 | 0.9297 | 0.2172 |

The model selection process used validation loss. The final test result was calculated after the best epoch had been selected.

Full per-class metrics and the 26 by 26 confusion matrix are stored in `model_resources/evaluation.json`. A spreadsheet-friendly version of the test confusion matrix is stored in `model_resources/test_confusion_matrix.csv`.

## Limitations

- The inputs are extracted numerical features, not raw images.
- The model is not a handwriting recogniser.
- Performance may change on records generated using a different feature-extraction process.
- Softmax confidence is not calibrated as a guaranteed probability of correctness.
- Manual GUI values can be within the allowed range without representing a realistic letter.

## Appropriate interpretation

The validation and test results are close, so there is no large validation-to-test gap. Training performance remains higher than test performance by 4.32 percentage points, indicating limited overfitting. The result should be interpreted for the UCI dataset and its measurement process only.

