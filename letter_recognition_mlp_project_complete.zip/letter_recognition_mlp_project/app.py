from __future__ import annotations

from flask import Flask, jsonify, render_template, request

from model_service import (
    ModelNotReadyError,
    actual_for_unchanged_sample,
    metadata,
    predict,
    random_test_sample,
    validate_features,
)


def create_app(testing=False):
    app = Flask(__name__)
    app.config.update(TESTING=testing, MAX_CONTENT_LENGTH=16 * 1024)

    @app.get("/")
    def home():
        return render_template("index.html")

    @app.get("/health")
    def health():
        try:
            details = metadata()
            return jsonify(
                {
                    "status": "ok",
                    "model": details["model"]["classifier"],
                    "dataset": details["dataset"]["name"],
                }
            )
        except ModelNotReadyError as exc:
            return jsonify({"status": "not_ready", "error": str(exc)}), 503

    @app.get("/api/metadata")
    def get_metadata():
        return jsonify(metadata())

    @app.get("/api/random-sample")
    def get_random_sample():
        return jsonify(random_test_sample())

    @app.post("/api/predict")
    def get_prediction():
        payload = request.get_json(silent=True)
        if not isinstance(payload, dict):
            return jsonify({"error": "Send a JSON object in the request body."}), 400
        if "features" not in payload:
            return jsonify({"error": "The request must include features."}), 400
        try:
            values = validate_features(payload["features"])
            result = predict(values.tolist())
        except ValueError as exc:
            return jsonify({"error": str(exc)}), 400
        actual = actual_for_unchanged_sample(payload.get("sample_id"), values)
        if actual is not None:
            result["actual_letter"] = actual
            result["correct"] = result["predicted_letter"] == actual
        return jsonify(result)

    @app.errorhandler(ModelNotReadyError)
    def model_not_ready(exc):
        return jsonify({"error": str(exc)}), 503

    @app.errorhandler(413)
    def request_too_large(_exc):
        return jsonify({"error": "The request is too large."}), 413

    return app


app = create_app()


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=False)

