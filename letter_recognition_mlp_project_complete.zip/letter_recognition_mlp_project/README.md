# Letter Recognition MLP Project

This is a complete introductory artificial-intelligence project based on the UCI Letter Recognition dataset. It trains a multilayer perceptron to classify capital letters A to Z from 16 numerical measurements and provides a Flask web interface for exploring predictions.

Use 64-bit Python 3.11 or newer. The supplied dependency versions have been tested with Python 3.13.

## What is included

- The official 20,000-record UCI dataset and its attribution information
- Separate training, validation and test sets
- A reproducible MLP training pipeline with feature standardisation and early stopping
- Saved model files and complete evaluation results
- A responsive browser interface
- Automated tests for the data, model and web application
- Student guides and a report template in the `docs` folder

## Important dataset limitation

The rows do not contain raw images. Each row contains 16 measurements that were previously extracted from a distorted image of a capital letter. The GUI therefore accepts these measurements; it cannot classify an uploaded photograph or a letter drawn with a mouse.

## Saved model performance

The included model was trained with random seed 42 and selected using validation loss.

| Dataset | Records | Accuracy | Macro F1 |
|---|---:|---:|---:|
| Training | 14,000 | 97.32% | 0.9730 |
| Validation | 2,000 | 92.45% | 0.9238 |
| Test | 4,000 | 93.00% | 0.9297 |

The training-to-test accuracy gap is 4.32 percentage points. Validation and test accuracy differ by only 0.55 points. This suggests some overfitting, but the held-out results are consistent and substantially more reliable than results from a very small test set.

## Quick start in Windows Command Prompt

Open Command Prompt, change to the project folder, and run:

```bat
cd /d C:\path\to\letter_recognition_mlp_project
setup.bat
run_tests.bat
run_app.bat
```

`run_app.bat` starts the server and opens http://127.0.0.1:5000 in the default browser. Press `Ctrl+C` in Command Prompt to stop the server.

The project already contains a trained model. Running `train_model.bat` is optional unless you want to reproduce the training process:

```bat
train_model.bat
```

## Manual commands

If batch files cannot be used:

```bat
python -m venv .venv
.venv\Scripts\python.exe -m pip install -r requirements.txt
.venv\Scripts\python.exe training.py
.venv\Scripts\python.exe -m unittest discover -s tests -v
.venv\Scripts\python.exe run_local.py
```

## Folder guide

```text
letter_recognition_mlp_project/
|-- app.py                         Flask routes and API validation
|-- model_service.py               Loads the model and creates predictions
|-- training.py                    Training and evaluation pipeline
|-- data_utils.py                  Dataset validation and splitting
|-- project_config.py              Shared paths and feature definitions
|-- run_local.py                   Starts the GUI and opens the browser
|-- data/
|   |-- letter-recognition.data    Official UCI data file
|   |-- letter-recognition.names   Original dataset description
|   |-- download_dataset.py        Optional reproducible downloader
|   |-- SOURCE.md                  Dataset citation and licence
|   `-- splits/                    Generated train, validation and test CSVs
|-- model_resources/
|   |-- model_bundle.joblib        Saved MLP and fitted scaler
|   |-- evaluation.json            Full metrics and per-class results
|   |-- training_history.csv       Results from every training epoch
|   |-- test_confusion_matrix.csv  Test confusion matrix
|   `-- test_predictions.csv       One prediction per test record
|-- templates/index.html           GUI page
|-- static/                        GUI styling and behaviour
|-- tests/                         Automated tests
`-- docs/                          Student documentation
```

## Recommended reading order

1. Read `docs/STUDENT_GUIDE.md`.
2. Read `docs/DATASET_GUIDE.md` before interpreting the feature values.
3. Run the GUI and test several examples.
4. Read `docs/MODEL_CARD.md` to understand the model and its limits.
5. Read `docs/RESULTS_GUIDE.md` to practise evidence-based interpretation.
6. Use `docs/REPORT_TEMPLATE.md` when writing the assessment report.

## Reproducibility

- Random seed: 42
- UCI rows 1 to 16,000: development data
- Development data: stratified into 14,000 training and 2,000 validation records
- UCI rows 16,001 to 20,000: untouched test data
- StandardScaler: fitted only on training inputs
- Best model: selected only using validation loss
- Test set: evaluated after the best epoch was selected

## Dataset citation

Slate, D. (1991). *Letter Recognition* [Dataset]. UCI Machine Learning Repository. https://doi.org/10.24432/C5ZP40
